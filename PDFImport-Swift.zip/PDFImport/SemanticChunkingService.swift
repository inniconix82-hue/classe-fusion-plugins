import Foundation

final class SemanticChunkingService {

    // MARK: - Public

    func chunk(from pages: [PDFChunk]) -> [SemanticChunk] {
        let raw    = extractRawBlocks(from: pages)
        let typed  = raw.map { RawBlock(text: $0.text, pageStart: $0.pageStart,
                                        pageEnd: $0.pageEnd,
                                        kind: detectKind(of: $0.text)) }
        let merged = mergeAdjacent(typed)
        return merged.enumerated().map { i, b in
            let (title, content) = splitTitleAndContent(b.text)
            return SemanticChunk(id: "chunk_\(i + 1)",
                                 pageStart: b.pageStart,
                                 pageEnd: b.pageEnd,
                                 title: title,
                                 content: content,
                                 kind: b.kind)
        }
    }

    // MARK: - Internal types

    private struct RawBlock {
        var text: String
        var pageStart: Int
        var pageEnd: Int
        var kind: ChunkKind = .text
    }

    // MARK: - Step 1 : extract raw blocks from pages

    private func extractRawBlocks(from pages: [PDFChunk]) -> [RawBlock] {
        pages.flatMap { page in
            splitParagraphs(page.text)
                .map { RawBlock(text: $0, pageStart: page.pageNumber, pageEnd: page.pageNumber) }
        }
    }

    private func splitParagraphs(_ text: String) -> [String] {
        text.components(separatedBy: "\n\n")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { $0.count > 25 }
    }

    // MARK: - Step 2 : detect kind

    private func detectKind(of text: String) -> ChunkKind {
        let lines = text
            .components(separatedBy: "\n")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }

        // Table: lines containing | or multiple tabs
        let tableLineCount = lines.filter {
            $0.contains("|") || $0.filter { $0 == "\t" }.count >= 2
        }.count
        if tableLineCount >= 2 { return .tableCandidate }

        // List: lines starting with bullet markers or numbered items
        let listPattern = #"^[\•\-\*\–\→·]|^\d+[\.\)]\s|^[a-zA-Z]\)\s"#
        let listLineCount = lines.filter {
            $0.range(of: listPattern, options: .regularExpression) != nil
        }.count
        if listLineCount >= 2 { return .list }

        // Source excerpt: quoted text or article/law references
        let sourcePatterns = [
            #"^[«"""]"#,
            #"^[Aa]rticle?\s+\d"#,
            #"^[Aa]rt\.\s"#,
            #"^[LRD]\.\s?\d{3}"#,
            #"^\§\s?\d"#,
            #"^Cf\.\s|^Voir\s|^Source\s?:"#
        ]
        if sourcePatterns.contains(where: { text.range(of: $0, options: .regularExpression) != nil }) {
            return .sourceExcerpt
        }

        // Constraint / rule / condition
        let lower = text.lowercased()
        let constraintKeywords = [
            "doit ", "ne doit pas", "ne peut pas", "il est interdit",
            "est tenu ", "obligatoire", "obligatoirement",
            "sous réserve", "à condition", "dans le cas où",
            "lorsque ", "sauf si", "uniquement si",
            "must ", "shall ", "shall not", "mandatory", "required"
        ]
        if constraintKeywords.contains(where: { lower.contains($0) }) {
            return .constraintCandidate
        }

        return .text
    }

    // MARK: - Step 3 : merge adjacent same-kind blocks

    private func mergeAdjacent(_ blocks: [RawBlock]) -> [RawBlock] {
        guard !blocks.isEmpty else { return [] }

        var result: [RawBlock] = []
        var current = blocks[0]

        for next in blocks.dropFirst() {
            let sameKind    = next.kind == current.kind
            let smallEnough = current.text.count + next.text.count < 800
            let contiguous  = next.pageStart <= current.pageEnd + 1
            let mergeable   = current.kind != .tableCandidate

            if sameKind && smallEnough && contiguous && mergeable {
                current.text    += "\n\n" + next.text
                current.pageEnd  = next.pageEnd
            } else {
                result.append(current)
                current = next
            }
        }
        result.append(current)
        return result
    }

    // MARK: - Step 4 : split title vs content

    private func splitTitleAndContent(_ text: String) -> (title: String?, content: String) {
        let lines = text.components(separatedBy: "\n")
        guard let first = lines.first else { return (nil, text) }

        let candidate = first.trimmingCharacters(in: .whitespaces)
        let rest = lines.dropFirst()
            .joined(separator: "\n")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        let looksLikeTitle = candidate.count < 90
            && !candidate.hasSuffix(".")
            && !rest.isEmpty
            && candidate.first?.isUppercase == true

        return looksLikeTitle ? (candidate, rest) : (nil, text)
    }
}
