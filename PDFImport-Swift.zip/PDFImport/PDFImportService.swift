import PDFKit
import AppKit

final class PDFImportService {

    @MainActor
    func selectAndLoad() -> PDFDocument? {
        let panel = NSOpenPanel()
        panel.title = "Sélectionner un PDF"
        panel.allowedContentTypes = [.pdf]
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        guard panel.runModal() == .OK, let url = panel.url else { return nil }
        return PDFDocument(url: url)
    }

    func extractChunks(from document: PDFDocument) -> [PDFChunk] {
        (0..<document.pageCount).compactMap { i in
            guard let page = document.page(at: i) else { return nil }
            return PDFChunk(
                id: "page_\(i + 1)",
                pageNumber: i + 1,
                text: page.string ?? ""
            )
        }
    }
}
