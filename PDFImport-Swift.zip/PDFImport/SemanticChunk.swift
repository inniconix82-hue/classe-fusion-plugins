import SwiftUI

// MARK: - Model

enum ChunkKind: String, CaseIterable, Identifiable {
    case text
    case list
    case tableCandidate
    case constraintCandidate
    case sourceExcerpt

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .text:                "Texte"
        case .list:                "Liste"
        case .tableCandidate:      "Tableau"
        case .constraintCandidate: "Contrainte"
        case .sourceExcerpt:       "Source"
        }
    }

    var icon: String {
        switch self {
        case .text:                "text.alignleft"
        case .list:                "list.bullet"
        case .tableCandidate:      "tablecells"
        case .constraintCandidate: "exclamationmark.triangle"
        case .sourceExcerpt:       "quote.bubble"
        }
    }

    var color: Color {
        switch self {
        case .text:                .secondary
        case .list:                .blue
        case .tableCandidate:      .purple
        case .constraintCandidate: .orange
        case .sourceExcerpt:       .green
        }
    }
}

struct SemanticChunk: Identifiable {
    let id: String
    let pageStart: Int
    let pageEnd: Int
    let title: String?
    let content: String
    let kind: ChunkKind
}

// MARK: - Helpers

extension SemanticChunk {
    var pageRangeLabel: String {
        pageStart == pageEnd ? "p. \(pageStart)" : "p. \(pageStart)–\(pageEnd)"
    }

    var preview: String {
        let t = content.trimmingCharacters(in: .whitespacesAndNewlines)
        guard t.count > 220 else { return t }
        return String(t.prefix(220)) + "…"
    }
}
