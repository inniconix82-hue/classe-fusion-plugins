import SwiftUI
import PDFKit

// MARK: - ViewModel

@MainActor
final class PDFImportViewModel: ObservableObject {
    @Published private(set) var document: PDFDocument?
    @Published private(set) var pages: [PDFChunk] = []
    @Published private(set) var semanticChunks: [SemanticChunk] = []
    @Published private(set) var fileName = ""
    @Published var selectedID: String?
    @Published var rightTab: RightTab = .pages

    enum RightTab { case pages, chunks }

    private let pdfService      = PDFImportService()
    private let chunkingService = SemanticChunkingService()

    func importPDF() {
        guard let doc = pdfService.selectAndLoad() else { return }
        document       = doc
        fileName       = doc.documentURL?.lastPathComponent ?? "Document"
        pages          = pdfService.extractChunks(from: doc)
        semanticChunks = chunkingService.chunk(from: pages)
        selectedID     = nil
    }
}

// MARK: - Root View

struct PDFImportView: View {
    @StateObject private var vm = PDFImportViewModel()

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            Divider()
            content
        }
        .frame(minWidth: 960, minHeight: 640)
    }

    // MARK: Toolbar

    private var toolbar: some View {
        HStack(spacing: 12) {
            Button { vm.importPDF() } label: {
                Label("Importer PDF", systemImage: "doc.badge.plus")
            }
            .buttonStyle(.borderedProminent)

            if !vm.fileName.isEmpty {
                Label(vm.fileName, systemImage: "doc.fill")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }

            Spacer()

            if !vm.pages.isEmpty {
                HStack(spacing: 16) {
                    stat(value: vm.pages.count,          label: "pages")
                    stat(value: vm.semanticChunks.count, label: "chunks")
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.bar)
    }

    private func stat(value: Int, label: String) -> some View {
        HStack(spacing: 4) {
            Text("\(value)")
                .font(.subheadline.weight(.semibold))
                .monospacedDigit()
            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    // MARK: Content

    @ViewBuilder
    private var content: some View {
        if let document = vm.document {
            HSplitView {
                PDFKitView(document: document)
                    .frame(minWidth: 420)
                rightPanel
                    .frame(minWidth: 300, maxWidth: 440)
            }
        } else {
            emptyState
        }
    }

    // MARK: Right panel

    private var rightPanel: some View {
        VStack(spacing: 0) {
            Picker("", selection: $vm.rightTab) {
                Text("Pages (\(vm.pages.count))")
                    .tag(PDFImportViewModel.RightTab.pages)
                Text("Chunks (\(vm.semanticChunks.count))")
                    .tag(PDFImportViewModel.RightTab.chunks)
            }
            .pickerStyle(.segmented)
            .padding(10)
            .background(.bar)

            Divider()

            switch vm.rightTab {
            case .pages:  pagesList
            case .chunks: chunksList
            }
        }
    }

    private var pagesList: some View {
        List(vm.pages, selection: $vm.selectedID) { page in
            ChunkRowView(chunk: page).tag(page.id)
        }
        .listStyle(.inset)
    }

    private var chunksList: some View {
        List(vm.semanticChunks, selection: $vm.selectedID) { chunk in
            SemanticChunkRowView(chunk: chunk).tag(chunk.id)
        }
        .listStyle(.inset)
    }

    // MARK: Empty state

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "doc.text.magnifyingglass")
                .font(.system(size: 56))
                .foregroundStyle(.tertiary)
            Text("Aucun PDF importé")
                .font(.title2).foregroundStyle(.secondary)
            Text("Cliquez sur « Importer PDF » pour commencer.")
                .font(.subheadline).foregroundStyle(.tertiary)
            Button("Importer PDF") { vm.importPDF() }
                .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - ChunkRowView (étape 1 — pages brutes)

struct ChunkRowView: View {
    let chunk: PDFChunk

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 8) {
                Text("Page \(chunk.pageNumber)")
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(Color.accentColor.opacity(0.12))
                    .foregroundStyle(.accent)
                    .clipShape(Capsule())

                Text(chunk.id)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .fontDesign(.monospaced)

                Spacer()

                Text("\(chunk.text.count) car.")
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .monospacedDigit()
            }

            if chunk.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Text("Aucun texte extrait")
                    .font(.caption).foregroundStyle(.tertiary).italic()
            } else {
                Text(chunk.preview)
                    .font(.caption).foregroundStyle(.secondary).lineLimit(3)
            }
        }
        .padding(.vertical, 3)
    }
}

// MARK: - SemanticChunkRowView (étape 2 — chunks sémantiques)

struct SemanticChunkRowView: View {
    let chunk: SemanticChunk

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 6) {
                Label(chunk.kind.displayName, systemImage: chunk.kind.icon)
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 7)
                    .padding(.vertical, 2)
                    .background(chunk.kind.color.opacity(0.12))
                    .foregroundStyle(chunk.kind.color)
                    .clipShape(Capsule())

                Text(chunk.pageRangeLabel)
                    .font(.caption2).foregroundStyle(.tertiary).monospacedDigit()

                Spacer()

                Text(chunk.id)
                    .font(.caption2).foregroundStyle(.tertiary).fontDesign(.monospaced)
            }

            if let title = chunk.title {
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
            }

            Text(chunk.preview)
                .font(.caption).foregroundStyle(.secondary).lineLimit(3)
        }
        .padding(.vertical, 4)
    }
}
