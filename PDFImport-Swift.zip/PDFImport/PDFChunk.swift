import Foundation

struct PDFChunk: Identifiable {
    let id: String        // "page_1", "page_2", …
    let pageNumber: Int
    let text: String

    var preview: String {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        return t.count > 220 ? String(t.prefix(220)) + "…" : t
    }
}
